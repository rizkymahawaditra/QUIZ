package com.example.loginapp

class RegisterActivity {
}