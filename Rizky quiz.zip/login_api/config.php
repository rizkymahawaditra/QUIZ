<?php

header('Content-Type: application/json; charset=utf-8');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli(
        'localhost',
        'root',
        '',
        'login_android'
    );

    $conn->set_charset('utf8mb4');

} catch (Throwable $e) {
    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Koneksi database gagal'
    ]);

    exit;
}

function response($success, $message, $data = null)
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);

    exit;
}

function inputJson()
{
    $data = json_decode(
        file_get_contents('php://input'),
        true
    );

    return is_array($data) ? $data : [];
}

?>