<?php

require 'config.php';

// Pastikan request menggunakan metode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    response(false, 'Gunakan metode POST');
}

// Ambil data JSON
$data = inputJson();

$nama = trim($data['nama'] ?? '');
$email = strtolower(trim($data['email'] ?? ''));
$password = $data['password'] ?? '';

// Validasi input
if (
    $nama === '' ||
    strlen($nama) > 100 ||
    !filter_var($email, FILTER_VALIDATE_EMAIL) ||
    strlen($email) > 150 ||
    !is_string($password) ||
    strlen($password) < 8
) {
    http_response_code(422);

    response(
        false,
        'Data tidak valid. Password minimal 8 karakter.'
    );
}

// Enkripsi password menggunakan password_hash
$hash = password_hash($password, PASSWORD_DEFAULT);

try {

    // Siapkan query registrasi
    $stmt = $conn->prepare(
        'INSERT INTO users (nama, email, password)
         VALUES (?, ?, ?)'
    );

    $stmt->bind_param(
        'sss',
        $nama,
        $email,
        $hash
    );

    // Jalankan query
    $stmt->execute();

    response(true, 'Registrasi berhasil');

} catch (mysqli_sql_exception $e) {

    // Periksa apakah email sudah terdaftar
    if ((int) $e->getCode() === 1062) {
        http_response_code(409);
        response(false, 'Email sudah terdaftar');
    }

    // Catat error untuk pemeriksaan server
    error_log($e->getMessage());

    http_response_code(500);
    response(false, 'Terjadi kesalahan server');
}

?>