<?php

require 'config.php';

// Pastikan request menggunakan metode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    response(false, 'Gunakan metode POST');
}

// Ambil data JSON
$data = inputJson();

$email = strtolower(trim($data['email'] ?? ''));
$password = $data['password'] ?? '';

// Validasi input
if (
    !filter_var($email, FILTER_VALIDATE_EMAIL) ||
    !is_string($password)
) {
    http_response_code(422);
    response(false, 'Email atau password tidak valid');
}

// Cari pengguna berdasarkan email
$stmt = $conn->prepare(
    'SELECT id, nama, email, password
     FROM users
     WHERE email = ?
     LIMIT 1'
);

$stmt->bind_param('s', $email);
$stmt->execute();

// Ambil data pengguna
$user = $stmt->get_result()->fetch_assoc();

// Verifikasi email dan password
if (
    !$user ||
    !password_verify($password, $user['password'])
) {
    http_response_code(401);
    response(false, 'Email atau password salah');
}

// Login berhasil
response(true, 'Login berhasil', [
    'id'    => (int) $user['id'],
    'nama'  => $user['nama'],
    'email' => $user['email']
]);

?>